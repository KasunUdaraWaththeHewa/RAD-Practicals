class Rectangle{
    constructor(w,h) {
        this.width = w;
        this.height = h;
    }
}
const rec1= new Rectangle(100,50);
console.log(rec1.height);
console.log(rec1.width);